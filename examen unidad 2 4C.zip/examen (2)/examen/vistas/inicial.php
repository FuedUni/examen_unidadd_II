

<!doctype html>
<?php
require "../config/conexion.php";
$query = "select * from users";
$resultado = mysqli_query($conexion,$query); 
include 'head.php';
?>
<body>
<?php 
include 'nav.php';
?>
<main>

<section class="featured-places">
            <div>
                <?php 
                if($resultado->num_rows === 0)
                {
                    echo 'Sin existencias de productos';
                }
                else
                {
                    
                foreach($resultado as $row){ ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="featured-item">
                                    <div class="thumb">
                                        <img src="../public/img/users/<?php echo $row['img']; ?>" alt="">
                                    </div>
                                    <div class="down-content">
                                        <h4><?php echo $row['nombre']; ?></h4>
                                        
                                        <p><?php echo $row['apellido']; ?></p>


                                    </div>
                                </div>
                            </div>
                <?php }
                }?>
            </div>
        </section>

<?php if( isset($_SESSION['id_user']) && !empty($_SESSION['id_user']) )
                               {
                                ?>
<iframe scrolling="no" src="usersform.php" style="padding:20px; height:850px;width:100%;border:none;" ></iframe> 
<?php } else{ ?>
    <p>no tienes permisos</p>
    <?php } ?>





</main>
<br><br><br>
<?php 
include 'footer.php';
?>
<?php 
include 'js.php';
?>
</body>

</html>
