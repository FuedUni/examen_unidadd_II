<link rel="stylesheet" href="../public/css/bootstrap.min.css">
    <link rel="stylesheet" href="../public/css/fontAwesome.css">
    <link rel="stylesheet" href="../public/css/hero-slider.css">
    <link rel="stylesheet" href="../public/css/owl-carousel.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <script src="../public/js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <div class="content-wrapper">        
        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-md-12">
                  <div class="box">
                    <div class="box-header with-border">
                          <h1 class="box-title">Usuarios <button class="btn btn-success" id="btnagregar" onclick="mostrarform(true)"><i class="fa fa-plus-circle"></i> Agregar</button></h1>
                        <div class="box-tools pull-right">
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <!-- centro -->
                    <div class="panel-body table-responsive" id="listadoregistros">
                        <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover">
                          <thead>
                            <th>Opciones</th>
                            <th>Nombre Completo</th>                           
                            <th>Tipo</th>
                            <th>clave</th>
                            <th>Email</th>
                            <th>Imagen de usuario</th>
                            <th>Avatar</th>
                            <th>Teléfono</th>
                          </thead>
                          <tbody>                            
                          </tbody>
                          <tfoot>

                          </tfoot>
                        </table>
                    </div>
                    <div class="panel-body" style="height: 400px;" id="formularioregistros">
                        <form name="formulario" id="formulario" method="POST" enctype="multipart/form-data">
                        <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Nombre de real:</label>
                            <input type="hidden" name="id_user" id="id_user">
                            <input type="text" class="form-control" name="nombre" id="nombre" maxlength="250" placeholder="Nombre" required>
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Apellido:</label>                          
                            <input type="text" class="form-control" name="apellido" id="apellido" maxlength="250" placeholder="Apellido" required>
                          </div>
                         
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Tipo:</label>
                            <input type="text" class="form-control" name="tipo" id="tipo" maxlength="256" placeholder="tipo">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>clave:</label>
                            <input type="text" class="form-control" name="clave" id="clave" maxlength="256" placeholder="clave">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Email:</label>
                            <input type="email" class="form-control" name="email" id="email" maxlength="256" placeholder="email">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Imagen:</label>
                            <input type="file" class="form-control" name="img" id="img" >
                            <input type="hidden" name="ia1" id="ia1">
                            <img src="" width="150px" height="120px" id="im1">
                          </div>              
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Teléfono:</label>
                            <input type="text" class="form-control" name="tel" id="tel" maxlength="256" placeholder="teléfono">
                          </div> 
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Avatar:</label>
                            <input type="text" class="form-control" name="avatar" id="avatar" maxlength="256" placeholder="Avatar">
                          </div> 
                          <br>

                          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i> Guardar</button>

                            <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
                          </div>
                        </form>
                    </div>
                    <!--Fin centro -->
                  </div><!-- /.box -->
              </div><!-- /.col -->
          </div><!-- /.row -->
      </section><!-- /.content -->

    </div><!-- /.content-wrapper -->
  <!--Fin-Contenido-->

    <!-- jQuery -->
    <script src="../Public/js/jquery-3.1.1.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../Public/js/bootstrap.min.js"></script>

    <!-- DATATABLES -->
    <script src="../Public/datatables/jquery.dataTables.min.js"></script>    
    <script src="../Public/datatables/dataTables.buttons.min.js"></script>
    <script src="../Public/datatables/buttons.html5.min.js"></script>
    <script src="../Public/datatables/buttons.colVis.min.js"></script>
    <script src="../Public/datatables/jszip.min.js"></script>
    <script src="../Public/datatables/pdfmake.min.js"></script>
    <script src="../Public/datatables/vfs_fonts.js"></script> 

    <script src="../Public/js/bootbox.min.js"></script> 
    <script src="../Public/js/bootstrap-select.min.js"></script>  
    <script type="text/javascript" src="scripts/users.js"></script>
