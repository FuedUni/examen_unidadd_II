<!doctype html>
<?php 
include 'head.php';
?>
<body>
<?php 
include 'nav.php';
?>
<main>
<iframe scrolling="no" src="usersform.php" style="padding:20px; height:850px;width:100%;border:none;" ></iframe> 
</main>
<br><br><br>
<?php 
include 'footer.php';
?>
<?php 
include 'js.php';
?>
</body>

</html>